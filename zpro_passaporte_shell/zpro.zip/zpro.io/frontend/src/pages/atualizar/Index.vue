<template>
  <q-page class="q-pa-md" v-if="userProfile === 'superadmin'">
    <div class="q-gutter-md row justify-around">
      <!-- Card para iniciar o processo de migração -->
      <q-card flat bordered class="my-card col-12 col-md-5">
        <q-card-section>
          <div class="text-center q-pa-md">
            <q-icon name="mdi-transfer" size="30px" color="negative" />
            <div class="text-h6">{{ $t('atualizar.migrationTitle') }}</div>
            <q-banner
              class="bg-yellow text-black"
              inline-actions
              style="margin-top: 10px;"
            >
              <p>{{ $t('atualizar.migrationBanner') }}</p>
            </q-banner>
          </div>
        </q-card-section>
        <q-card-actions align="center" class="q-pa-md">
          <q-btn
            color="negative"
            @click="startMigrationProcess"
            class="q-mt-sm"
          >
            {{ $t('atualizar.migrationButton') }}
          </q-btn>
        </q-card-actions>
      </q-card>

      <!-- Card para iniciar o processo de limpeza -->
      <q-card flat bordered class="my-card col-12 col-md-5">
        <q-card-section>
          <div class="text-center q-pa-md">
            <q-icon name="mdi-delete-outline" size="30px" color="negative" />
            <div class="text-h6">{{ $t('atualizar.cleanTitle') }}</div>
            <q-banner
              class="bg-yellow text-black"
              inline-actions
              style="margin-top: 10px;"
            >
              <p>{{ $t('atualizar.cleanBanner') }}</p>
            </q-banner>
          </div>
        </q-card-section>
        <q-card-actions align="center" class="q-pa-md">
          <q-btn color="negative" @click="startCleanProcess" class="q-mt-sm">
            {{ $t('atualizar.cleanButton') }}
          </q-btn>
        </q-card-actions>
      </q-card>
    </div>
  </q-page>
</template>

<script>
import { UploadZip, Update, MigrarArquivos, LimparArquivos } from 'src/service/customizar';

export default {
  data() {
    return {
      userProfile: 'user',
      uploading: false,
      updatingProcess: false,
      selectedUpdateFile: null,
      selectedFileName: '',
      uploadProgress: 0,
      updateReady: false,
    };
  },
  methods: {
    triggerUpdateFileInput() {
      this.$refs.updateFileInput.click();
    },
    handleUpdateFileUpload(event) {
      const target = event.target;
      if (target.files && target.files.length > 0) {
        const file = target.files[0];
        if (file.name === 'update_rapido.zip') {
          this.selectedUpdateFile = file;
          this.selectedFileName = file.name;
        } else {
          this.selectedUpdateFile = null;
          this.selectedFileName = '';
          this.$q.notify({
            color: 'negative',
            message: this.$t("atualizar.fileValidationError"),
            timeout: 2000
          });
        }
      }
    },
    async uploadUpdateFile() {
      if (!this.selectedUpdateFile) return;

      const formData = new FormData();
      formData.append('file', this.selectedUpdateFile);

      this.uploading = true;
      this.uploadProgress = 0;

      try {
        const response = await UploadZip(formData, {
          onUploadProgress: (progressEvent) => {
            this.uploadProgress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          }
        });
        if (response.status === 200) {
          this.updateReady = true;
          this.$q.notify({
            color: 'positive',
            message: this.$t("atualizar.uploadSuccess"),
            timeout: 2000
          });
        } else {
          this.$q.notify({
            color: 'negative',
            message: this.$t("atualizar.uploadError"),
            timeout: 2000
          });
        }
      } catch (error) {
        this.$q.notify({
          color: 'negative',
          message: this.$t("atualizar.uploadError") + JSON.stringify(error),
          timeout: 2000
        });
      } finally {
        this.uploading = false;
        this.uploadProgress = 0;
      }
    },
    async startUpdateProcess() {
      this.updatingProcess = true;
      try {
        const response = await Update();
        if (response.status === 200) {
          this.$q.notify({
            color: 'positive',
            message: this.$t("atualizar.updateStartSuccess"),
            timeout: 2000
          });
        } else {
          this.$q.notify({
            color: 'negative',
            message: this.$t("atualizar.updateStartError"),
            timeout: 2000
          });
        }
      } catch (error) {
        this.$q.notify({
          color: 'negative',
          message: this.$t("atualizar.updateStartError") + JSON.stringify(error),
          timeout: 2000
        });
      }
      setTimeout(() => {
        this.updatingProcess = false;
      }, 20000); // Simulação de tempo de execução do processo
    },
    async startMigrationProcess() {
      try {
        const response = await MigrarArquivos();
        if (response.status === 200) {
          this.$q.notify({
            color: 'positive',
            message: this.$t("atualizar.migrationStartSuccess"),
            timeout: 2000
          });
        } else {
          this.$q.notify({
            color: 'negative',
            message: this.$t("atualizar.migrationStartError"),
            timeout: 2000
          });
        }
      } catch (error) {
        this.$q.notify({
          color: 'negative',
          message: this.$t("atualizar.migrationStartError") + JSON.stringify(error),
          timeout: 2000
        });
      }
    },
    async startCleanProcess() {
      try {
        const response = await LimparArquivos();
        if (response.status === 200) {
          this.$q.notify({
            color: 'positive',
            message: this.$t("atualizar.cleanStartSuccess"),
            timeout: 2000
          });
        } else {
          this.$q.notify({
            color: 'negative',
            message: this.$t("atualizar.cleanStartError"),
            timeout: 2000
          });
        }
      } catch (error) {
        this.$q.notify({
          color: 'negative',
          message: this.$t("atualizar.cleanStartError") + JSON.stringify(error),
          timeout: 2000
        });
      }
    },
  },
  mounted() {
    this.userProfile = localStorage.getItem('profile');
  },
};
</script>

<style scoped>
.my-card {
  margin: 20px auto;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}
</style>
